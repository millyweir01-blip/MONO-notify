package com.mono.notify;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b) { super.onCreate(b);
 LinearLayout l=new LinearLayout(this); l.setOrientation(1);l.setPadding(44,70,44,30);l.setBackgroundColor(Color.rgb(16,16,18));
 TextView t=new TextView(this);t.setText("MONO / NOTIFY\n\nPrivate, expandable home-screen notification widget.\n\nAdd the widget after enabling access. Lock-screen placement depends on Samsung/Good Lock support.");t.setTextColor(-1);t.setTextSize(18);l.addView(t);
 Button btn=new Button(this);btn.setText("ENABLE NOTIFICATION ACCESS");btn.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));l.addView(btn);setContentView(l);
 }
}
