package com.mono.notify;
import android.app.*;
import android.appwidget.*;
import android.content.*;
import android.graphics.Color;
import android.os.Build;
import android.service.notification.StatusBarNotification;
import android.widget.*;
import android.view.View;
import java.util.*;
public class NotifyWidget extends AppWidgetProvider {
 static final String TOGGLE="com.mono.notify.TOGGLE";
 @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)render(c,m,id);}
 @Override public void onReceive(Context c,Intent i){super.onReceive(c,i);if(TOGGLE.equals(i.getAction())){int id=i.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,-1);if(id!=-1){boolean open=c.getSharedPreferences("mono",0).getBoolean("open_"+id,false);c.getSharedPreferences("mono",0).edit().putBoolean("open_"+id,!open).apply();render(c,AppWidgetManager.getInstance(c),id);}}}
 static void refresh(Context c){AppWidgetManager m=AppWidgetManager.getInstance(c);int[] ids=m.getAppWidgetIds(new ComponentName(c,NotifyWidget.class));for(int id:ids)render(c,m,id);}
 static void render(Context c,AppWidgetManager m,int id){
 boolean expanded=c.getSharedPreferences("mono",0).getBoolean("open_"+id,false);
 RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget);
 ArrayList<StatusBarNotification> ns=new ArrayList<>();
 try {if(NotifyListener.active!=null){StatusBarNotification[] a=NotifyListener.active.getActiveNotifications();if(a!=null)for(StatusBarNotification n:a){if(n.isOngoing()||n.getNotification()==null)continue;ns.add(n);}}}catch(Exception ignored){}
 ns.sort((a,b)->Long.compare(b.getPostTime(),a.getPostTime()));
 v.setTextViewText(R.id.header,"MONO  /  "+ns.size()+" NOTIFICATIONS    "+(expanded?"−":"+"));
 Intent toggle=new Intent(c,NotifyWidget.class).setAction(TOGGLE).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id);
 toggle.setData(android.net.Uri.parse("mono://toggle/"+id));
 v.setOnClickPendingIntent(R.id.header,PendingIntent.getBroadcast(c,id,toggle,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
 v.removeAllViews(R.id.items);
 if(NotifyListener.active==null)v.setTextViewText(R.id.status,"Open MONO Notify to enable access");
 else v.setTextViewText(R.id.status,ns.isEmpty()?"All clear":"Tap + to "+(expanded?"collapse":"expand"));
 if(expanded){int count=0;for(StatusBarNotification n:ns){if(count++>=5)break;
 String app=n.getPackageName();try{app=c.getPackageManager().getApplicationLabel(c.getPackageManager().getApplicationInfo(app,0)).toString();}catch(Exception ignored){}
 CharSequence title=n.getNotification().extras.getCharSequence("android.title","");
 CharSequence body=n.getNotification().extras.getCharSequence("android.text","");
 String line=app+"  ·  "+title+(body.length()>0?"\n"+body:"");
 RemoteViews row=new RemoteViews(c.getPackageName(),R.layout.notification_row);row.setTextViewText(R.id.notification_text,line);
 PendingIntent tap=n.getNotification().contentIntent;if(tap!=null)row.setOnClickPendingIntent(R.id.notification_text,tap);
 v.addView(R.id.items,row);
 }}
 m.updateAppWidget(id,v);
 }
}
