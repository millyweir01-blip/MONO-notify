package com.mono.notify;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
public class NotifyListener extends NotificationListenerService {
 static volatile NotifyListener active;
 @Override public void onListenerConnected(){active=this;NotifyWidget.refresh(this);}
 @Override public void onListenerDisconnected(){active=null;NotifyWidget.refresh(this);}
 @Override public void onNotificationPosted(StatusBarNotification sbn){NotifyWidget.refresh(this);}
 @Override public void onNotificationRemoved(StatusBarNotification sbn){NotifyWidget.refresh(this);}
}
