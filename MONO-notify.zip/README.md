# MONO Notify

Minimal Android home-screen notification widget. Charcoal panel, compact count, tap-to-expand five latest notification previews. Requires explicit Android notification-listener access. No network permission or cloud processing.

## Build
Push these files to GitHub. GitHub Actions builds a debug APK on `main` and provides it under the workflow run's **Artifacts** section. You can also open the project in Android Studio (JDK 17, SDK 35).

## Use
Install the APK, open MONO Notify, enable notification access in Android Settings, add the **MONO Notify** home-screen widget, and tap the header to expand/collapse. Resize the widget vertically to see more previews.

## Important limitation
This is a **home-screen AppWidget**. Samsung Good Lock/LockStar does not guarantee that arbitrary interactive home-screen widgets can be used on the lock screen. This project does not bypass Android lock-screen security or guarantee lock-screen notification expansion.

## Privacy
Notification content stays on the phone. No internet permission. Previews may expose sensitive content to people viewing your unlocked home screen.
